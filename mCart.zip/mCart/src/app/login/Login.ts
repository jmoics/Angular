//model for Login
export class Login {
        public userName: string;
        public password: string;
}
